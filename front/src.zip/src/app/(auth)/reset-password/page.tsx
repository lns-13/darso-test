import type { Metadata } from "next";
import Link from "next/link";

import { createClient } from "@/lib/supabase/server";
import { ResetPasswordForm } from "./reset-password-form";

export const metadata: Metadata = {
  title: "Nouveau mot de passe · darso",
  description: "Choisissez un nouveau mot de passe pour votre compte darso.",
};

/**
 * Where the password-reset email lands, via /auth/callback. The
 * forgot-password screen has been sending links since it was designed; until
 * now there was nowhere for them to arrive.
 *
 * Reaching this page means the recovery code was already exchanged for a real
 * session, so `getUser()` answers. When it does not — the link expired, was
 * used twice, or was opened on a different device than the one that asked —
 * the page says so instead of showing a form that could only fail. That is
 * this page reading its own precondition, not a route guard: guards are
 * Task 03.
 */
export default async function ResetPasswordPage() {
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();

  if (!data.user) {
    return (
      <div className="space-y-8">
        <header>
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-[#8A8D93]">
            Lien expiré
          </p>
          <h1
            className="mt-2 text-[26px] sm:text-[30px] md:text-[32px] font-extrabold leading-[1.05] tracking-[-0.035em] text-[#0B0B0F]"
            style={{ fontFamily: "var(--font-cabinet), system-ui, sans-serif" }}
          >
            Ce lien n&apos;est
            <br />
            plus valide.
          </h1>
          <p className="mt-3 text-[13px] leading-relaxed text-[#4A4D54]">
            Les liens de réinitialisation expirent au bout de 30 minutes et ne
            servent qu&apos;une fois. Demandez-en un nouveau, et ouvrez-le sur
            l&apos;appareil depuis lequel vous l&apos;avez demandé.
          </p>
        </header>

        <Link
          href="/forgot-password"
          className="flex min-w-full items-center justify-center rounded-full bg-[#0B0B0F] px-3 py-3 text-[13px] font-semibold text-white transition-[filter] hover:brightness-[1.15]"
        >
          Demander un nouveau lien
        </Link>

        <p className="text-center text-[12.5px] text-[#4A4D54]">
          <Link
            href="/sign-in"
            className="font-semibold text-[#0B0B0F] underline-offset-4 hover:underline"
          >
            ← Retour à la connexion
          </Link>
        </p>
      </div>
    );
  }

  return <ResetPasswordForm email={data.user.email ?? ""} />;
}
