/**
 * Where a signed-in person belongs, and how we ask.
 *
 * The role is read from `profiles.role` — never from `user.user_metadata.role`,
 * which the user can rewrite from the browser. The sign-up trigger copies the
 * whitelisted metadata role into that column once, at creation, and no policy
 * reads the metadata again. `private.user_role()` is a policy helper and is
 * not callable through `supabase.rpc()`, so this is a plain select; a
 * signed-in user can always read their own profiles row.
 */

import type { SupabaseClient } from "@supabase/supabase-js";

export type UserRole = "student" | "teacher";

export const STUDENT_HOME = "/student";
export const TEACHER_HOME = "/teacher";

export function homeForRole(role: UserRole | null | undefined): string {
  return role === "teacher" ? TEACHER_HOME : STUDENT_HOME;
}

/**
 * Reads the role of the currently signed-in user. Returns null when signed
 * out or when the profiles row is somehow missing, which callers treat as
 * "send them to the student dashboard" rather than as an error.
 */
export async function readUserRole(
  supabase: SupabaseClient,
  userId: string,
): Promise<UserRole | null> {
  const { data, error } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", userId)
    .maybeSingle();

  if (error || !data) return null;
  const role = (data as { role?: string }).role;
  return role === "teacher" || role === "student" ? role : null;
}

/** The dashboard path for the signed-in user, resolved from the database. */
export async function homeForUser(
  supabase: SupabaseClient,
  userId: string,
): Promise<string> {
  return homeForRole(await readUserRole(supabase, userId));
}

/**
 * Only ever redirect to a path inside this app. Guards the `next` parameter
 * on /auth/callback, which arrives from an email link and is therefore
 * attacker-influenced: "//evil.com" is a protocol-relative URL, not a path.
 */
export function safeNextPath(next: string | null | undefined): string | null {
  if (!next) return null;
  if (!next.startsWith("/") || next.startsWith("//")) return null;
  return next;
}
