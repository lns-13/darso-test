"use server";

/**
 * Every auth mutation in the product. All of them run on the server, so
 * nothing the caller can rewrite is ever trusted.
 *
 * The signature is (prevState, formData) throughout because the forms consume
 * these through `useActionState`, which hands back [state, action, pending].
 * That pending flag is what drives the submit button now — see the note on
 * the `status` prop in components/library/stateful-button.tsx.
 *
 * Validation is re-run here with the shared module, never taken on trust from
 * the client. Two rules matter especially: the birth-date plausibility range
 * and the guardian email for minors. Both are database check constraints, and
 * a violated constraint fails the auth.users insert itself — no account is
 * created and the UI has no French string for the raw Postgres error.
 */

import { headers } from "next/headers";
import { redirect } from "next/navigation";

import { createClient } from "@/lib/supabase/server";
import {
  AUTH_MESSAGES,
  composeBirthDate,
  computeAge,
  isMinor,
  validateEmail,
  validateIdentity,
  validatePassword,
  type FieldErrors,
} from "./validation";
import { homeForUser } from "./routes";
import type {
  OtpState,
  ResetRequestState,
  SignInState,
  SignUpState,
  UpdatePasswordState,
} from "./state";

/* ------------------------------------------------------------------ *
 * helpers
 * ------------------------------------------------------------------ */

/**
 * Absolute origin for the links Supabase mails out. Prefers an explicit
 * NEXT_PUBLIC_SITE_URL so production links do not depend on a proxy header;
 * falls back to the request host in development.
 */
async function siteOrigin(): Promise<string> {
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (configured) return configured.replace(/\/+$/, "");

  const requestHeaders = await headers();
  const host =
    requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host");
  const isLocal =
    host?.startsWith("localhost") || host?.startsWith("127.0.0.1") || false;
  const proto =
    requestHeaders.get("x-forwarded-proto") ?? (isLocal ? "http" : "https");
  return `${proto}://${host ?? "localhost:3000"}`;
}

type SupabaseAuthError = { code?: string; status?: number; message: string };

/**
 * Supabase speaks English and returns error codes; the product speaks French
 * and has a fixed set of slots. Anything unmapped becomes the generic string
 * rather than leaking a provider message into the UI.
 */
function messageForAuthError(error: SupabaseAuthError): string {
  const code = error.code ?? "";

  if (code === "invalid_credentials") return AUTH_MESSAGES.invalidCredentials;
  // Supabase runs its own address checks on top of ours and rejects some
  // domains outright, example.com among them. Reuse the designed string
  // rather than showing the generic one for a problem the user can fix.
  if (code === "email_address_invalid" || code === "validation_failed")
    return AUTH_MESSAGES.emailInvalid;
  if (code === "email_not_confirmed") return AUTH_MESSAGES.emailNotConfirmed;
  if (code === "user_already_exists" || code === "email_exists")
    return AUTH_MESSAGES.emailTaken;
  if (code === "otp_disabled" || code === "user_not_found")
    return AUTH_MESSAGES.unknownEmail;
  if (code === "same_password") return AUTH_MESSAGES.samePassword;
  if (code === "weak_password") return AUTH_MESSAGES.passwordTooShort;
  if (
    code === "otp_expired" ||
    code === "flow_state_expired" ||
    code === "flow_state_not_found" ||
    code === "bad_code_verifier"
  )
    return AUTH_MESSAGES.linkInvalid;
  if (
    error.status === 429 ||
    code === "over_email_send_rate_limit" ||
    code === "over_request_rate_limit"
  )
    return AUTH_MESSAGES.rateLimited;

  return AUTH_MESSAGES.unexpected;
}

function readString(formData: FormData, key: string): string {
  const value = formData.get(key);
  return typeof value === "string" ? value : "";
}

function hasErrors(errors: FieldErrors): boolean {
  return Object.keys(errors).length > 0;
}

/* ------------------------------------------------------------------ *
 * sign in — password
 * ------------------------------------------------------------------ */

export async function signIn(
  _prevState: SignInState,
  formData: FormData,
): Promise<SignInState> {
  const email = readString(formData, "email").trim();
  const password = readString(formData, "password");

  const errors: FieldErrors = {};
  const emailError = validateEmail(email);
  if (emailError) errors.email = emailError;
  const passwordError = validatePassword(password);
  if (passwordError) errors.password = passwordError;
  if (hasErrors(errors)) return { status: "error", errors };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error || !data.user) {
    return {
      status: "error",
      errors: {
        form: error
          ? messageForAuthError(error)
          : AUTH_MESSAGES.invalidCredentials,
      },
    };
  }

  // Role-correct landing. Sign-in used to hardcode /student for everyone.
  redirect(await homeForUser(supabase, data.user.id));
}

/* ------------------------------------------------------------------ *
 * sign in — magic link
 * ------------------------------------------------------------------ */

export async function signInWithOtp(
  _prevState: OtpState,
  formData: FormData,
): Promise<OtpState> {
  const email = readString(formData, "email").trim();

  const emailError = validateEmail(email);
  if (emailError)
    return { status: "error", email, errors: { email: emailError } };

  const supabase = await createClient();
  const origin = await siteOrigin();

  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: {
      // The default creates an auth.users row for an unknown address, and the
      // sign-up trigger would then turn it into a student profile named after
      // the email local part with no birth date. Never that.
      shouldCreateUser: false,
      emailRedirectTo: `${origin}/auth/callback`,
    },
  });

  if (error)
    return {
      status: "error",
      email,
      errors: { form: messageForAuthError(error) },
    };

  return { status: "sent", email, errors: {} };
}

/* ------------------------------------------------------------------ *
 * sign up
 * ------------------------------------------------------------------ */

export async function signUp(
  _prevState: SignUpState,
  formData: FormData,
): Promise<SignUpState> {
  const identity = {
    fullName: readString(formData, "fullName"),
    email: readString(formData, "email"),
    password: readString(formData, "password"),
    dobD: readString(formData, "dobD"),
    dobM: readString(formData, "dobM"),
    dobY: readString(formData, "dobY"),
    parentEmail: readString(formData, "parentEmail"),
  };
  const email = identity.email.trim();

  const errors = validateIdentity(identity);
  if (hasErrors(errors)) return { status: "error", email, errors };

  // Anything that is not exactly "teacher" is a student, matching the
  // trigger's whitelist. The role is read once, at creation, and is immutable
  // afterwards, so this call is the only chance to get it right.
  const role =
    readString(formData, "role") === "teacher" ? "teacher" : "student";

  const age = computeAge(identity.dobD, identity.dobM, identity.dobY);
  const birthDate = composeBirthDate(
    identity.dobD,
    identity.dobM,
    identity.dobY,
  );

  // Never trust the client on the guardian email: if the person is 18 or over
  // the value is dropped here whatever the form submitted. The trigger drops
  // it a second time, for the same reason.
  const guardianEmail = isMinor(age) ? identity.parentEmail.trim() : "";

  const fullName = identity.fullName.trim() || email.split("@")[0];

  const supabase = await createClient();
  const origin = await siteOrigin();

  const { data, error } = await supabase.auth.signUp({
    email,
    password: identity.password,
    options: {
      emailRedirectTo: `${origin}/auth/callback`,
      // Exactly the four keys private.handle_new_user() reads. It creates
      // profiles, profiles_private and the role row; we never insert them.
      data: {
        full_name: fullName,
        role,
        birth_date: birthDate,
        guardian_email: guardianEmail,
      },
    },
  });

  if (error)
    return {
      status: "error",
      email,
      errors: { form: messageForAuthError(error) },
    };

  // With confirmations on, Supabase answers an already-registered address
  // with a decoy user carrying no identities rather than with an error.
  if (data.user && (data.user.identities?.length ?? 0) === 0)
    return {
      status: "error",
      email,
      errors: { form: AUTH_MESSAGES.emailTaken },
    };

  // Auto-confirm is off, so there is normally no session here. If that
  // project setting ever changes, land the person on the right dashboard
  // instead of showing a "check your mail" screen for an email never sent.
  if (data.session && data.user) {
    redirect(await homeForUser(supabase, data.user.id));
  }

  return { status: "confirm", email, errors: {} };
}

/* ------------------------------------------------------------------ *
 * password reset — request the link
 * ------------------------------------------------------------------ */

export async function requestPasswordReset(
  _prevState: ResetRequestState,
  formData: FormData,
): Promise<ResetRequestState> {
  const email = readString(formData, "email").trim();

  const emailError = validateEmail(email);
  if (emailError)
    return { status: "error", email, errors: { email: emailError } };

  const supabase = await createClient();
  const origin = await siteOrigin();

  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${origin}/auth/callback?next=/reset-password`,
  });

  // Supabase answers an unknown address with success on purpose, so this
  // screen cannot be used to discover which emails have accounts. Only real
  // failures — rate limits, transport — reach here.
  if (error)
    return {
      status: "error",
      email,
      errors: { form: messageForAuthError(error) },
    };

  return { status: "sent", email, errors: {} };
}

/* ------------------------------------------------------------------ *
 * password reset — set the new password
 * ------------------------------------------------------------------ */

export async function updatePassword(
  _prevState: UpdatePasswordState,
  formData: FormData,
): Promise<UpdatePasswordState> {
  const password = readString(formData, "password");
  const confirmation = readString(formData, "passwordConfirm");

  const passwordError = validatePassword(password, { isNew: true });
  if (passwordError)
    return { status: "error", errors: { password: passwordError } };
  if (confirmation !== password)
    return {
      status: "error",
      errors: { passwordConfirm: AUTH_MESSAGES.passwordsDiffer },
    };

  const supabase = await createClient();

  // The recovery link created a real session when /auth/callback exchanged
  // its code. Without that session there is nothing to update.
  const { data: userData } = await supabase.auth.getUser();
  if (!userData.user)
    return {
      status: "error",
      errors: { form: AUTH_MESSAGES.recoverySessionMissing },
    };

  const { error } = await supabase.auth.updateUser({ password });
  if (error)
    return { status: "error", errors: { form: messageForAuthError(error) } };

  redirect(await homeForUser(supabase, userData.user.id));
}

/* ------------------------------------------------------------------ *
 * sign out
 * ------------------------------------------------------------------ */

export async function signOut(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/sign-in");
}
